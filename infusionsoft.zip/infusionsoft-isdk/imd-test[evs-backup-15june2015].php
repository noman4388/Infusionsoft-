<?php 
	# name : imd_hub_cron.php 
	# desc : send leads from IMD to HUB via cron
	# version: 1.0
  	# changelog: 
	# 			2012/03/05 [Vikal]: start develop.

	//error_reporting(E_ALL);
	//ini_set("display_errors", 1);
	

	# Connect to DB
	
	//require_once("\\\\webcontent01\\dev\\marketing\\__shared_library\\db_imd_connect.php");
	
	require_once("\\\\webcontent01\\WebContent\\marketing\\__shared_library\\db_imd_connect.php");
	# Include libraries
		//require_once("\\\\webcontent01\\dev\\marketing\\__shared_library\\email_notification.php");		
	require_once("\\\\webcontent01\\WebContent\\marketing\\__shared_library\\email_notification.php");
	
	require_once("isdk.php");	
	# Initialize variables
	$info = array();
	$lsds_tables = array('imd_ppc_new_survey', 'imd_ppc_yahoo_survey', 'imd_ppc_msn_survey', 'imd_ppc_fb_survey', 'imd_wf_new_survey'); // LSDS tables
	$i = 0;
	
	# Fetch the leads which have not been sent to HUB, Flag - is_sent_to_hub = 0
	$qry = "	
		SELECT p.id_detail, p.id_addr, p.id_src, p.id_lead, p.id_center, p.first_name, p.last_name, CONCAT(p.area_code, '-', p.phone) AS phone, a.addr_street, a.addr_unit, a.city, a.state_code, a.zip_code, la.id_acc, la.email_addr, c.center_code,
			(SELECT ppc.id_ppc
				FROM 
					`imd_ppc` AS ppc,
					`imd_ppc_ans`AS ppc_ans
				WHERE 
					(ppc.id_ppc=ppc_ans.id_ppc) AND
					(ppc_ans.id_detail = p.id_detail)
				LIMIT 1
			UNION
			SELECT wf.id_wf
				FROM 
					`imd_wf` AS wf,
					`imd_wf_ans`AS wf_ans
				WHERE 
					(wf.id_wf=wf_ans.id_wf) AND
					(wf_ans.id_detail = p.id_detail)
				LIMIT 1) AS source,
			(SELECT ppc.table_name
				FROM 
					`imd_ppc` AS ppc,
					`imd_ppc_ans`AS ppc_ans
				WHERE 
					(ppc.id_ppc=ppc_ans.id_ppc) AND
					(ppc_ans.id_detail = p.id_detail)
				LIMIT 1
			UNION
			SELECT wf.table_name
				FROM 
					`imd_wf` AS wf,
					`imd_wf_ans`AS wf_ans
				WHERE 
					(wf.id_wf=wf_ans.id_wf) AND
					(wf_ans.id_detail = p.id_detail)
				LIMIT 1) AS table_name,
			(SELECT ppc_ans.id_ans
				FROM 
					`imd_ppc` AS ppc,
					`imd_ppc_ans`AS ppc_ans
				WHERE 
					(ppc.id_ppc=ppc_ans.id_ppc) AND
					(ppc_ans.id_detail = p.id_detail)
				LIMIT 1
			UNION
			SELECT wf_ans.id_ans
				FROM 
					`imd_wf` AS wf,
					`imd_wf_ans`AS wf_ans
				WHERE 
					(wf.id_wf=wf_ans.id_wf) AND
					(wf_ans.id_detail = p.id_detail)
				LIMIT 1) AS id_ans
		FROM 
			`imd_person_detail` AS p, 
			`lrx_address` AS a, 
			`imd_lead_account` AS la, 
			`imd_lead` AS l, 
			`lrx_center` AS c
		WHERE 
			(p.id_addr = a.id_addr) AND 
			(p.id_lead = l.id_lead) AND 
			(l.id_acc = la.id_acc) AND 
			(p.id_center = c.id_center) AND 
			(p.date_added >= DATE_SUB(NOW(), INTERVAL 1 DAY)) AND
			(p.is_sent_to_infusoft = 0) limit 6
		";
		//(p.date_added >= DATE_SUB(NOW(), INTERVAL 1 DAY)) AND
		
	//echo $qry; exit;
	$sql = mysql_query($qry) or die('IMD-HUB: SELECT query unsuccessful.');
	$num = mysql_num_rows($sql);
	echo "Total number of leads found - ".(int)$num."<br/>";
	//exit;
	if((int)$num > 0) {
		while($item = mysql_fetch_object($sql)){
           //echo "test";
		  // echo "<pre>";
		   //print_r($item);
		   //echo "</pre>"; exit;
		  
		   //$infoLeadFirstName = $item->first_name;
		   //echo $infoLeadFirstName; exit;
			// Initializing variables
			$comment = "";
			$webinarRegDate = "";
			$webinarAttended = "";
			$interestrating = "-1";
			$jointime = "";
			$leavetime = "";
			$duration = "-1";
			$question = "";
			$attention = "-1";
			$logic_reason = "-1";
			$memory = "-1";
			$process_speed = "-1";
			$audit_process = "-1";
			$visual_process = "-1";
			$age = "";
			$concerns = array();
			$keyword = "";
			
			//$info["ConfirmationEmail"] = 'lrx.nationwide@gmail.com';
			$info["ConfirmationEmail"] = 'webemails@learningrx.com';
			$info["AccountID"] = $item->id_acc;
			//$info["LeadSource"] = getLeadSource($item->id_src);
			//$info["LeadSource"] = getLeadSource($item->source);
			$info["LeadID"] = $item->id_detail;
			$info["CenterCode"] = (empty($item->center_code))?"CO99":$item->center_code;

			 $info["LeadFirstName"] = $item->first_name;
			 $info["LeadLastName"] = $item->last_name;
			 $info["LeadAddress"] = $item->addr_street;
			 mb_detect_encoding(iconv("utf-8","iso-8859-1",$item->last_name));
		

			
			$info["LeadCity"] = $item->city;
			$info["LeadState"] = ($item->state_code == "AA")?"??":$item->state_code;
			$info["LeadZip"] = $item->zip_code;
			$info["PhoneNumber"] = ($item->phone == "-")?"":$item->phone;
			$info["Email"] = $item->email_addr;
			
			if(!empty($item->table_name) && !empty($item->id_ans)) { // Checking if table name and answer ID exist
				if(in_array($item->table_name, $lsds_tables)) { // Checking if table name exist in LSDS tables
					if($item->table_name == 'imd_wf_new_survey'){
						$col_keyword = '';
						$info["LeadSource"] = 4; // Overriding LeadSource: 4 - Web: LSDS
					} else {
						$col_keyword = ', keyword';
						$info["LeadSource"] = 3; // Overriding LeadSource: 3 - Pay-Per-Click: LSDS
					}
				
		$sql2 = mysql_query("SELECT 	attention, logic_reason, memory, process_speed, audit_process, visual_process, age, concerns".$col_keyword."
										FROM ".$item->table_name." 
										WHERE (id_ans =".$item->id_ans.") LIMIT 1");	
					$row = mysql_fetch_object($sql2);

					$attention = $row->attention;
					$logic_reason = $row->logic_reason;
					$memory = $row->memory;
					$process_speed = $row->process_speed;
					$audit_process = $row->audit_process;
					$visual_process = $row->visual_process;
					$age = $row->age;
					$age = $age[0];
					$concerns = unserialize($row->concerns);

					if(!empty($row->keyword)) $keyword = $row->keyword;  
					else $keyword = "null";
				} else {
					if($item->table_name != 'imd_ppc_game_pack'){
						$col_keyword = '';
						//$info["LeadSource"] =4 ; // Overriding LeadSource: 4 - Web: LSDS
					} else {
						$col_keyword = ', keyword';
						//$info["LeadSource"] = 3; // Overriding LeadSource: 3 - Pay-Per-Click: LSDS
					}
					$sql3 = mysql_query("SELECT * FROM ".$item->table_name." WHERE (id_ans =".$item->id_ans.") limit 1");	

					if((int)mysql_num_rows($sql3) > 0){
						$row2 = mysql_fetch_object($sql3);
						foreach($row2 as $key => $val){
							switch($item->table_name){
								case "imd_wf_webinar_gtw":
															switch ($key){
																case "date_register"		: 
																							$webinarRegDate = date("m/d/Y", strtotime($val));
																							break;
																case "attended"			: 
																							$webinarAttended = strtoupper($val);
																							break;
																case "interest_rating"	: 
																							$interestrating = $val;
																							break;
																case "join_time"			: 
																							$jointime = substr($val, strpos($val, " ")+1, strlen($val));
																							break;
																case "leave_time"		: 
																							$leavetime = substr($val, strpos($val, " ")+1, strlen($val));
																							break;
																case "duration"			: 
																							$duration = $val;
																							break;
																case "question" 			:
																							$question = $val;
																							break;
															}
															break;

								default 					: 
															switch ($key){
																case "comment" 			: 
																case "field_comment" 	:
																case "prospect_note" 	:
																case "question" 			:
																case "main_concern" 		:
																							$comment = $val;
																							break;
															}
							}
						}
					}
				}
			}
		    
			$info["WebinarRegistrationDate"] = $webinarRegDate;
			$info["WebinarAttended"] = $webinarAttended;
			$info["WebinarInterestRating"] = $interestrating;
			$info["WebinarJoinTime"] = $jointime;
			$info["WebinarLeaveTime"] = $leavetime;
			$info["WebinarInSessionDuration"] = $duration;
			$info["WebinarQuestionsAskedByAttendee"] = $question;
			
			$info["LSDSAdultChild"] = $age;
			
			if(is_array($concerns) && in_array("Reading", $concerns)) 
				$info["LSDSConcernsReading"] = 1;
			else 
				$info["LSDSConcernsReading"] = 0;
			
			if(is_array($concerns) && in_array("Attention", $concerns)) 
				$info["LSDSConcernsAttention"] = 1;
			else
				$info["LSDSConcernsAttention"] = 0;
			
			if(is_array($concerns) && in_array("Low Grades", $concerns)) 
				$info["LSDSConcernsLowGrades"] = 1;
			else
				$info["LSDSConcernsLowGrades"] = 0;

			if(is_array($concerns) && in_array("Slow Work", $concerns)) 
				$info["LSDSConcernsWorksSlowly"] = 1;
			else
				$info["LSDSConcernsWorksSlowly"] = 0;
		
			if(is_array($concerns) && in_array("Math", $concerns)) 
				$info["LSDSMath"] = 1;
			else
				$info["LSDSMath"] = 0;
		
			if(is_array($concerns) && in_array("Memory", $concerns)) 
				$info["LSDSMemory"] = 1;
			else
				$info["LSDSMemory"] = 0;
		
			if(is_array($concerns) && in_array("Visual Processing", $concerns)) 
				$info["LSDSVisualProcessing"] = 1;
			else
				$info["LSDSVisualProcessing"] = 0;
		
			if(is_array($concerns) && in_array("Logic & Reasoning", $concerns)) 
				$info["LSDSLogicReasoning"] = 1;
			else
				$info["LSDSLogicReasoning"] = 0;
		
			if(is_array($concerns) && in_array("Autism", $concerns)) 
				$info["LSDSAutism"] = 1;
			else
				$info["LSDSAutism"] = 0;
		
			if(is_array($concerns) && in_array("Homework", $concerns)) 
				$info["LSDSHomeWork"] = 1;
			else
				$info["LSDSHomeWork"] = 0;
		
			if(is_array($concerns) && in_array("Other", $concerns)) 
				$info["LSDSConcernsOther"] = $concerns[count($concerns)-1];
			else
				$info["LSDSConcernsOther"] = "";
	
			$info["LSDSSurveyAttentionSkills"] = $attention;
			$info["LSDSSurveyProcessingSpeedSkills"] = $process_speed;
			$info["LSDSSurveyAuditoryProcessingSkills"] = $audit_process;
			$info["LSDSSurveyMemorySkills"] = $memory;
			$info["LSDSSurveyVisualProcessingSkills"] = $visual_process;
			$info["LSDSSurveyLogicReasoningSkills"] = $logic_reason;
			$info["LSDSSurveySensoryMotorSkills"] = 0;
			$info["LSDSSurveyOppositionalBehavior"] = 0;
			$info["LSDSPPCKeyWord"] = $keyword;

			$info["ContactUsQuestionComment"] = $comment;
			$info["CallCenterLeadStatus"] = "";
			$info["CallCenterChildOrAdult"] = "";
			$info["CallCenterCallDetailsNotes"] = "";
			$info["CallCenterChildClientName"] = "";
			$info["ChildClientDateOfBirth"] = "";

			$params = array('newLead' => $info);
			//$i++;echo $i." - sendLeadToHub, Source - ".$item->id_src.", Table_name - ".$item->table_name.", Id_ans - ".$item->id_ans."<br >";

			//sendLeadToHub($params);
			sendLeadToinfusionsoft($params);
		
		}
	}
	function sendLeadToinfusionsoft($data = array()){
                echo "<pre>";
				print_r($data);
                echo "</pre>"; 
				//exit;
				$app = new iSDK;
				$sourceid   = $data['newLead']['LeadSource'];	
				$total = array(4=>9997, 3=>3063, 2=>3064, 5=>9992, 6=>3064, 8=>9996, 9=>9996, 10=>13226, 16=>9994, 20=>9995, 21=>9996, 22=>11053, 23=>11057, 26=>13227, 27=>9993);		
				$firstname  = $data['newLead']['LeadFirstName'];
				$lastname  = $data['newLead']['LeadLastName'];
				$phonenumber  = $data['newLead']['PhoneNumber'];
				
				$email      = $data['newLead']['Email'];
				$city       = $data['newLead']['LeadCity'];
				$state      = $data['newLead']['LeadState'];
				$zipcode    = $data['newLead']['LeadZip'];
				$centercode = $data['newLead']['CenterCode'];
				$source_id   = $total[$sourceid];
				
	if ($app->cfgCon("connectionName")) { 
	$data1a = array('FirstName' => $firstname,    // The key on the left must exact match table field names
	'LastName'     => $lastname, 
	'Phone1'       => $phonenumber, 
	'PostalCode'   => $zipcode,
	'Email'        => $email,
	'City'   	   => $city,
	'State'   	   => $state,
	'Country'      => $country,
	'_CenterCode'  => $centercode,
	'_HubMarketingSourceID' => $source_id );        // e.g you cannot put a string in date field
	$adddata = $app->addWithDupCheck($data1a, 'Email');
	mysql_query("UPDATE imd_person_detail SET is_sent_to_infusoft=1 WHERE id_detail=".(int)$data['newLead']['LeadID']) or die(mysql_error());
	echo "Contact added sucessfully<br>";
	echo "New inserted id is".$adddata; 
				}
else
{
echo "Not Connected...";
}
		
			
	}