<?php
 
// Connect to Infusionsoft 
require_once("/var/www/learningrx.com/infusionsoft-isdk/isdk.php");
$app = new iSDK;
 
if ($app->cfgCon("connectionName")) {
	        $all_contacts = array();        
        $page = 0;
        
        $returnFields = array('Id','FirstName','Leadsource','LeadSourceId','ContactNotes','_CenterCode','LastName','_IMDID','Phone1','_Gender','PostalCode','City','DateCreated','_LSDSAttention','_LSDSProcessing','_LSDSAuditory','_LSDSMemory','_LSDSVisual','_LSDSReasoning');
        
		if(!empty($_GET['LeadSourceId'])){
			$query = array('LeadSourceId' => $_GET['LeadSourceId']);
		}else{
			$query = array('Email' => '%');
		}
		

        while(true)
        {
            $results = $app->dsQuery("Contact", 200, $page, $query, $returnFields);
                        
            $all_contacts = array_merge($all_contacts, $results);
            
            if(count($results) <= 200)
            {
                break;
            }
        
            $page++;
        }
        echo "<pre>";
        print_r($all_contacts);
		echo "</pre>";
	} else {
echo "Not Connected...";
}
?>