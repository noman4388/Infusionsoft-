# iSDK
This is a clean copy of the deprecated Infusionsoft SDK (pre-oAuth)
