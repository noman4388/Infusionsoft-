<?php
echo "hhhh";
$myfile = fopen('/var/www/__shared_library/infusionsoft-isdk/'.time()."newfile.txt", "w") or die("Unable to open file!");
$txt = "John Doe\n";
fwrite($myfile, $txt);
$txt = "Jane Doe\n";
fwrite($myfile, $txt);
fclose($myfile);
exit;

// Connect to Infusionsoft
 
require_once("isdk.php");
$app = new iSDK;
 
if ($app->cfgCon("connectionName")) {
 
 $fname = 'tester';
 $lname = 'testing';
 $email = 'tester@test.com';
// Current date in Infusionsoft-friendly format
 
$currentDate = date_format(date_create(), 'YmdTH:i:s');
echo "You connected at $currentDate <br/>";
// Update contact record using AddWithDupCheck method
$data = array('FirstName' => $fname,    // The key on the left must exact match table field names
'LastName' => $lname,       // The value on the right can be anything as long as type matches field
'Email' => $email,
'_CenterCode'=>'trx005');        // e.g you cannot put a string in date field
$update = $app->addWithDupCheck($data, 'Email');  // This is the API call which checks for duplicates using Email and Name
 
echo $update;  // If successful, this will return the contactId of the contact added or updated
 
} else {
echo "Not Connected...";
}
?>