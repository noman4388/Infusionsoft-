<?php 

	# name : imd_infsoft_leads_cron.php 
	# desc : send leads from IMD to Infusionsoft via cron
	# version: 1.0
  	# changelog: 
	# Develop By: Noman Akhtar

	//error_reporting(E_ALL);
	//ini_set("display_errors", 1);
	

	# Connect to DB
	
	
	
	require_once("/var/www/__shared_library/db_imd_connect.php");
	# Include libraries
			
	require_once("/var/www/__shared_library/email_notification.php");
	
	require_once("/var/www/__shared_library/infusionsoft-isdk/isdk.php");	
	
	function getLeadSource($id){
		switch($id){
			case 2:              // Webinar
					return 26; 
					break;			
			case 3:             // LSDS
					return 22;
					break;	
			case 4:             // LSDS
					return 24;
					break;						
			case 5: // Web:Â LearningRx.comÂ Contact Form
					return 28;
					break;
			case 6: // Web:Â Web / Webinar
					return 26;
					break;
			case 8: // Web: LSDS - version B
					return 24;
					break;
			case 9: // Web: BrainBuzz Sign-Up Form
					return 40;
					break;		
			case 27: // Web: BrainBuzz Sign-Up Form
					return 40;
					break;
			case 10: // PPC: Game Pack added by azhar on 24-03-2014
					return $id;
					break;
			case 16: // Web: 2011 LearningRx Results Report Download
					return 34;
					break;
			case 20: // Web: Life Changing Magazine Download
					return 36;
					break;
			case 21: // Web: 7 Principles Email Series
					return 30;
					break;
			case 22: // Web: Vital Connections Book Download
					return 38;
					break;
			case 23: // Web: Purpose Directed Business Download
					return $id;
					break;		
			case 26: // Web: Game Pack
					return 32;
					break;	
			case 7:
			       return 26;
				   break;
			case 29:
				  return 2294;
				  break;
			case 30:
				 return 2406;
				 break;
			case 31:
			     return 2408;
				 break;   		  		   		 	
			default: 
					return ;
		}
	}
	# Initialize variables
	$info = array();
	$lsds_tables = array('imd_ppc_new_survey', 'imd_ppc_yahoo_survey', 'imd_ppc_msn_survey', 'imd_ppc_fb_survey', 'imd_wf_new_survey'); // LSDS tables
	$i = 0;
	
	# Fetch the leads which have not been sent to HUB, Flag - is_sent_to_hub = 0
	$qry = "	
		SELECT p.id_detail, p.id_addr, p.id_src, p.id_lead, p.id_center, p.first_name, p.last_name, p.gender, p.date_added, p.birth_date, CONCAT(p.area_code, '-', p.phone) AS phone, a.addr_street, a.addr_street2, a.addr_unit, a.city, a.state_code, a.zip_code, la.id_acc, la.email_addr, c.center_code,
			(SELECT ppc.id_ppc
				FROM 
					`imd_ppc` AS ppc,
					`imd_ppc_ans`AS ppc_ans
				WHERE 
					(ppc.id_ppc=ppc_ans.id_ppc) AND
					(ppc_ans.id_detail = p.id_detail)
				LIMIT 1
			UNION
			SELECT wf.id_wf
				FROM 
					`imd_wf` AS wf,
					`imd_wf_ans`AS wf_ans
				WHERE 
					(wf.id_wf=wf_ans.id_wf) AND
					(wf_ans.id_detail = p.id_detail)
				LIMIT 1) AS source,
			(SELECT ppc.table_name
				FROM 
					`imd_ppc` AS ppc,
					`imd_ppc_ans`AS ppc_ans
				WHERE 
					(ppc.id_ppc=ppc_ans.id_ppc) AND
					(ppc_ans.id_detail = p.id_detail)
				LIMIT 1
			UNION
			SELECT wf.table_name
				FROM 
					`imd_wf` AS wf,
					`imd_wf_ans`AS wf_ans
				WHERE 
					(wf.id_wf=wf_ans.id_wf) AND
					(wf_ans.id_detail = p.id_detail)
				LIMIT 1) AS table_name,
			(SELECT ppc_ans.id_ans
				FROM 
					`imd_ppc` AS ppc,
					`imd_ppc_ans`AS ppc_ans
				WHERE 
					(ppc.id_ppc=ppc_ans.id_ppc) AND
					(ppc_ans.id_detail = p.id_detail)
				LIMIT 1
			UNION
			SELECT wf_ans.id_ans
				FROM 
					`imd_wf` AS wf,
					`imd_wf_ans`AS wf_ans
				WHERE 
					(wf.id_wf=wf_ans.id_wf) AND
					(wf_ans.id_detail = p.id_detail)
				LIMIT 1) AS id_ans
		FROM 
			`imd_person_detail` AS p, 
			`lrx_address` AS a, 
			`imd_lead_account` AS la, 
			`imd_lead` AS l, 
			`lrx_center` AS c
		WHERE 
			(p.id_addr = a.id_addr) AND 
			(p.id_lead = l.id_lead) AND 
			(l.id_acc = la.id_acc) AND 
			(p.id_center = c.id_center) AND 
			(p.date_added >= DATE_SUB(NOW(), INTERVAL 1 DAY)) AND
			(p.is_sent_to_infusoft = 0)
		";
		//(p.date_added >= DATE_SUB(NOW(), INTERVAL 1 DAY)) AND
		
	//echo $qry; exit;
	$sql = mysql_query($qry) or die('IMD: SELECT query unsuccessful.');
	$num = mysql_num_rows($sql);
	echo "Total number of leads found - ".(int)$num."<br/>";
	//exit;
	if((int)$num > 0) {
		while($item = mysql_fetch_object($sql)){
             
					 
			 /*
			 echo "<pre>";
			 print_r($item);
			 echo "</pre>";
			*/
			
			// Initializing variables
			$comment = "";
			$webinarRegDate = "";
			$webinarAttended = "";
			$interestrating = "-1";
			$jointime = "";
			$leavetime = "";
			//$duration = "-1";
			$duration = "";
			$question = "";
			//$attention = "-1";
			$attention = "";
			//$logic_reason = "-1";
			$logic_reason = "";
			//$memory = "-1";
			$memory = "";
			//$process_speed = "-1";
			$process_speed = "";
			//$audit_process = "-1";
			$audit_process = "";
			//$visual_process = "-1";
			$visual_process = "";
			$age = "";
			$concerns = array();
			$keyword = "";
			
			//$info["ConfirmationEmail"] = 'lrx.nationwide@gmail.com';
			$info["ConfirmationEmail"] = 'webemails@learningrx.com';
			$info["AccountID"] = $item->id_acc;
			
			$info["LeadSource"] = getLeadSource($item->source);
			//$info['subjectline'] = $item->subjec_tline; 
			
			//echo $info["LeadSource"]; exit;
			//$info["LeadSource"] = getLeadSource($item->source);
			$info["LeadID"] 	= $item->id_detail;
			$info["CenterCode"] = (empty($item->center_code))?"CO99":$item->center_code;

			 $info["LeadFirstName"] =  $item->first_name;
			 $info["LeadLastName"]  =  $item->last_name;
			 $info["LeadAddress"]   =  $item->addr_street;
			 $info["LeadAddress2"]  =  $item->addr_street2;
			 $info['gender']        =  $item->gender;
			 $info['dateadded']     =  $item->date_added;
			 $info['birthdate']     =  $item->birth_date;
			 
			 mb_detect_encoding(iconv("utf-8","iso-8859-1",$item->last_name));
			
			$info["LeadCity"]  	 	= $item->city;
			$info["LeadState"] 		= ($item->state_code == "AA")?"??":$item->state_code;
			$info["LeadZip"]   		= $item->zip_code;
			$info["PhoneNumber"] 	= ($item->phone == "-")?"":$item->phone;
			$info["Email"] 			= $item->email_addr;
			
			
          
			if($item->table_name=='imd_ppc_contact_us'){
		
			$result_cont = mysql_query("select main_concern from imd_ppc_contact_us where id_ans = ".$item->id_ans.""); 
			$countrows   = mysql_num_rows($result_cont);
			if($countrows>0){
			$cont_record = mysql_fetch_assoc($result_cont);
			$info["data_contact"] = $cont_record['main_concern'];
			}
			}
			elseif($item->table_name=='imd_wf_contact_us'){
			
			
			$result_cont = mysql_query("select * from imd_wf_contact_us where id_ans = ".$item->id_ans.""); 
			$countrows   = mysql_num_rows($result_cont);
			if($countrows>0){
			$cont_record = mysql_fetch_assoc($result_cont);
			$info["data_contact"] = $cont_record['comment'];
			$info['subjectline']  = $cont_record['subject_line'];
			}
			}
			if(!empty($item->table_name) && !empty($item->id_ans)) { // Checking if table name and answer ID exist
				if(in_array($item->table_name, $lsds_tables)) { // Checking if table name exist in LSDS tables
					if($item->table_name == 'imd_wf_new_survey'){
						$col_keyword = '';
						$info["LeadSource"] = getLeadSource('4'); // Overriding LeadSource: 4 - Web: LSDS
					} else {
						$col_keyword = ', keyword';
						$info["LeadSource"] = getLeadSource('3'); // Overriding LeadSource: 3 - Pay-Per-Click: LSDS
					}
				
		$sql2 = mysql_query("SELECT 	attention, logic_reason, memory, process_speed, audit_process, visual_process, age, concerns".$col_keyword."
										FROM ".$item->table_name." 
										WHERE (id_ans =".$item->id_ans.") LIMIT 1");	
					$row = mysql_fetch_object($sql2);

					$attention = $row->attention;
					$logic_reason = $row->logic_reason;
					$memory = $row->memory;
					$process_speed = $row->process_speed;
					$audit_process = $row->audit_process;
					$visual_process = $row->visual_process;
					$age = $row->age;
					$info["age"] = $age; 
					$age = $age[0];
					$concerns = unserialize($row->concerns);

					if(!empty($row->keyword)) $keyword = $row->keyword;  
					else $keyword = "null";
				} else {
					if($item->table_name != 'imd_ppc_game_pack'){
						$col_keyword = '';
						//$info["LeadSource"] =4 ; // Overriding LeadSource: 4 - Web: LSDS
					} else {
						$col_keyword = ', keyword';
						//$info["LeadSource"] = 3; // Overriding LeadSource: 3 - Pay-Per-Click: LSDS
					}
					$sql3 = mysql_query("SELECT * FROM ".$item->table_name." WHERE (id_ans =".$item->id_ans.") limit 1");	

					if((int)mysql_num_rows($sql3) > 0){
						$row2 = mysql_fetch_object($sql3);
						foreach($row2 as $key => $val){
							switch($item->table_name){
								case "imd_wf_webinar_gtw":
															switch ($key){
																case "date_register"		: 
																							$webinarRegDate = date("m/d/Y", strtotime($val));
																							break;
																case "attended"			: 
																							$webinarAttended = strtoupper($val);
																							break;
																case "interest_rating"	: 
																							$interestrating = $val;
																							break;
																case "join_time"			: 
																							$jointime = substr($val, strpos($val, " ")+1, strlen($val));
																							break;
																case "leave_time"		: 
																							$leavetime = substr($val, strpos($val, " ")+1, strlen($val));
																							break;
																case "duration"			: 
																							$duration = $val;
																							break;
																case "question" 			:
																							$question = $val;
																							break;
															}
															break;

								default 					: 
															switch ($key){
																case "comment" 			: 
																case "field_comment" 	:
																case "prospect_note" 	:
																case "question" 			:
																case "main_concern" 		:
																							$comment = $val;
																							break;
															}
							}
						}
					}
				}
			}
		    
			$info["WebinarRegistrationDate"] = $webinarRegDate;
			$info["WebinarAttended"] = $webinarAttended;
			$info["WebinarInterestRating"] = $interestrating;
			$info["WebinarJoinTime"] = $jointime;
			$info["WebinarLeaveTime"] = $leavetime;
			$info["WebinarInSessionDuration"] = $duration;
			$info["WebinarQuestionsAskedByAttendee"] = $question;
			
			$info["LSDSAdultChild"] = $age;
			
			if(is_array($concerns) && in_array("Reading", $concerns)) 
				$info["LSDSConcernsReading"] = 1;
			else 
				$info["LSDSConcernsReading"] = 0;
			
			if(is_array($concerns) && in_array("Attention", $concerns)) 
				$info["LSDSConcernsAttention"] = 1;
			else
				$info["LSDSConcernsAttention"] = 0;
			
			if(is_array($concerns) && in_array("Low Grades", $concerns)) 
				$info["LSDSConcernsLowGrades"] = 1;
			else
				$info["LSDSConcernsLowGrades"] = 0;

			if(is_array($concerns) && in_array("Slow Work", $concerns)) 
				$info["LSDSConcernsWorksSlowly"] = 1;
			else
				$info["LSDSConcernsWorksSlowly"] = 0;
		
			if(is_array($concerns) && in_array("Math", $concerns)) 
				$info["LSDSMath"] = 1;
			else
				$info["LSDSMath"] = 0;
		
			if(is_array($concerns) && in_array("Memory", $concerns)) 
				$info["LSDSMemory"] = 1;
			else
				$info["LSDSMemory"] = 0;
		
			if(is_array($concerns) && in_array("Visual Processing", $concerns)) 
				$info["LSDSVisualProcessing"] = 1;
			else
				$info["LSDSVisualProcessing"] = 0;
		
			if(is_array($concerns) && in_array("Logic & Reasoning", $concerns)) 
				$info["LSDSLogicReasoning"] = 1;
			else
				$info["LSDSLogicReasoning"] = 0;
		
			if(is_array($concerns) && in_array("Autism", $concerns)) 
				$info["LSDSAutism"] = 1;
			else
				$info["LSDSAutism"] = 0;
		
			if(is_array($concerns) && in_array("Homework", $concerns)) 
				$info["LSDSHomeWork"] = 1;
			else
				$info["LSDSHomeWork"] = 0;
		
			if(is_array($concerns) && in_array("Other", $concerns)) 
				$info["LSDSConcernsOther"] = $concerns[count($concerns)-1];
			else
				$info["LSDSConcernsOther"] = "";
	
			$info["LSDSSurveyAttentionSkills"]          =  $attention;
			$info["LSDSSurveyProcessingSpeedSkills"]    =  $process_speed;
			$info["LSDSSurveyAuditoryProcessingSkills"] =  $audit_process;
			$info["LSDSSurveyMemorySkills"]             =  $memory;
			$info["LSDSSurveyVisualProcessingSkills"]   =  $visual_process;
			$info["LSDSSurveyLogicReasoningSkills"]     =  $logic_reason;
			$info["LSDSSurveySensoryMotorSkills"]       =  0;
			$info["LSDSSurveyOppositionalBehavior"]     =  0;
			$info["LSDSPPCKeyWord"]                     =  $keyword;

			$info["ContactUsQuestionComment"] = $comment;
			$info["CallCenterLeadStatus"] = "";
			$info["CallCenterChildOrAdult"] = "";
			$info["CallCenterCallDetailsNotes"] = "";
			$info["CallCenterChildClientName"] = "";
			$info["ChildClientDateOfBirth"] = "";

			$params = array('newLead' => $info);
			//$i++;echo $i." - sendLeadToHub, Source - ".$item->id_src.", Table_name - ".$item->table_name.", Id_ans - ".$item->id_ans."<br >";

			//sendLeadToHub($params);
			sendLeadToinfusionsoft($params);
		
		}
	}
	function sendLeadToinfusionsoft($data = array()){
               
	    if(!is_array($data) or count($data) == 0) {
			reportSystemError('IMD-HUB: Wrong data passed to INFUSIONSOFT', 'Following data was passed: '.var_export($data, true));
			return false;
		}
				
				/*
				echo "<pre>";
				print_r($data);
                echo "</pre>"; 
				exit;
				*/
				
				
				
				$app = new iSDK;					
				//$total = array(4=>9997, 3=>3063, 2=>3064, 5=>9992, 6=>3064, 8=>9996, 9=>9996, 10=>13226, 16=>9994, 20=>9995, 21=>9996, 22=>11053, 23=>11057, 26=>13227, 27=>9993);	
				//// initialize variable to send it infusionsoft	
				$sourceid   		= 	$data['newLead']['LeadSource'];
				$subjectline		=   $data['newLead']['subjectline'];
				$firstname         	= 	$data['newLead']['LeadFirstName'];
				$lastname   		= 	$data['newLead']['LeadLastName'];
				$leadid     		= 	$data['newLead']['LeadID'];
				$phonenumber  		= 	$data['newLead']['PhoneNumber'];
				$email      		= 	$data['newLead']['Email'];
				$streeadres1        =   $data['newLead']['LeadAddress'];
				$streeadres2        =   $data['newLead']['LeadAddress2'];
				$dateadded			=   $data['newLead']['dateadded'];
				$birthdate			=   $data['newLead']['birthdate']; 
				$age_con            =   $data['newLead']['age'];
				if($age_con=='Adult'){
					$age = '1';
					}
				else{
					$age = '0';
					}	
				$gender_con             =   $data['newLead']['gender'];	
				if($gender_con=='M' ){
					$gender = 'Male';
					}
				elseif($gender_con=='F' ){
					$gender = 'Female';
					}
				else{
					$gender = 'UnKnown';
					}		
				$city       		= 	$data['newLead']['LeadCity'];
				$state      		= 	$data['newLead']['LeadState'];
				$zipcode    		= 	$data['newLead']['LeadZip'];
				$centercode 		= 	$data['newLead']['CenterCode'];
				$leadsource 		= 	$data['newLead']['LeadSource'];
				$lsdsattention     	= 	$data['newLead']['LSDSSurveyAttentionSkills'];
				$lsdsprocessing   	= 	$data['newLead']['LSDSSurveyProcessingSpeedSkills'];
				$lsdsauditory       = 	$data['newLead']['LSDSSurveyAuditoryProcessingSkills'];
				$lsdsmemory         = 	$data['newLead']['LSDSSurveyMemorySkills'];
				$lsdsvisual         = 	$data['newLead']['LSDSSurveyVisualProcessingSkills'];
				$lsdsreasoning      = 	$data['newLead']['LSDSSurveyLogicReasoningSkills'];
				$personid           =   $data['newLead']['AccountID'];
				$contact_notes		=   $data['newLead']['ContactUsQuestionComment'];
				$source_id          = 	$total[$sourceid];
				
				/////// initialize tag variables
				
				$read_tag= $data['newLead']['LSDSConcernsReading'];
				if($read_tag=='1'){
					$reading_tag='200';
					}
				else {
					$reading_tag='0';
					}
			  $atten_tag= $data['newLead']['LSDSConcernsAttention'];	
			  	if($atten_tag=='1'){
					$attention_tag='190';
					}
				else {
					$attention_tag='0';
					}
			$work_tag= $data['newLead']['LSDSConcernsWorksSlowly'];	
			  	if($work_tag=='1'){
					$workslow_tag='194';
					}
				else {
					$workslow_tag='0';
					}
			$mth_tag= $data['newLead']['LSDSMath'];	
			  	if($mth_tag=='1'){
					$math_tag='192';
					}
				else {
					$math_tag='0';
					}	
			$memry_tag= $data['newLead']['LSDSMemory'];	
			  	if($memry_tag=='1'){
					$memory_tag='202';
					}
				else {
					$memory_tag='0';
					}	
			$visual_tag= $data['newLead']['LSDSVisualProcessing'];	
			  	if($visual_tag=='1'){
					$visualprcess_tag='204';
					}
				else {
					$visualprcess_tag='0';
					}
			$reasoning_tag= $data['newLead']['LSDSLogicReasoning'];	
			  	if($reasoning_tag=='1'){
					$logicreason_tag='196';
					}
				else {
					$logicreason_tag='0';
					}	
			$autsm_tag= $data['newLead']['LSDSAutism'];	
			  	if($autsm_tag=='1'){
					$autism_tag='206';
					}
				else {
					$autism_tag='0';
					}	
			$hwork_tag= $data['newLead']['LSDSHomeWork'];	
			  	if($hwork_tag=='1'){
					$homework_tag='198';
					}
				else {
					$homework_tag='0';
					}
			$othr_tag= $data['newLead']['LSDSConcernsOther'];	

			  	if($othr_tag=='1'){
					$other_tag='208';
					}
				else {
					$other_tag='0';
					}							
			/////// end tag variables ////////
				
	if ($app->cfgCon("connectionName")) { 
	$data_contact       = array('FirstName' => $firstname,    // The key on the left must exact match table field names
	'LastName'     		=>  $lastname, 
	'_IMDID'	   		=>  $leadid,
	//'_HubID'	        =>  $personid,
	'Phone1'       		=>  $phonenumber, 
	'_IsAdult'          =>  $age,
	'_Gender'           =>  $gender,   
	'PostalCode'   		=>  $zipcode,
	'Email'        		=>  $email,
	'City'   	   		=>  $city,
	'State'   	   		=>  $state,
	'Country'     		=>  $country,
	'ContactNotes'      =>  $contact_notes,    // add contact note in person notes
	//'ContactNotes'      =>  $contact_notes,
	'_AssessmentDate'   =>  $dateadded,
	'Birthday'          =>  $birthdate,
	'StreetAddress1'    =>  $streeadres1, 
	'StreetAddress2'    =>  $streeadres2, 
	'LeadSourceId' 		=>  $leadsource,
	'_LSDSAttention' 	=>  $lsdsattention,
	'_LSDSProcessing' 	=>  $lsdsprocessing,
	'_LSDSAuditory'  	=>  $lsdsauditory,
	'_LSDSMemory'  		=>  $lsdsmemory,
	'_LSDSVisual'  		=>  $lsdsvisual,
	'_LSDSReasoning' 	=>  $lsdsreasoning,
	'_CenterCode'  		=> $centercode); 
	//$adddata = $app->updateCon('750',$data_contact);   //update a existing record
	//'_HubMarketingSourceID' => $source_id ;        // e.g you cannot put a string in date field
	
	
	
	if($sourceid == '28')
	{
	// infusionsoft data insertion
	if(!empty($subjectline) && $subjectline == 'Imlookingforhelpformyselformychild'){
	$adddata  =  $app->addWithDupCheck($data_contact, 'Email');    // add contact by checking duplicate record
	//echo "sucessfully sent to infusionsoft";
	//echo "<pre>"; print_r($data_contact); echo "</pre>";
	}
	else{
	$cont	   =	mysql_query("UPDATE imd_person_detail SET is_sent_to_infusoft=3 WHERE id_detail=".(int)$data['newLead']['LeadID']) or die(mysql_error());
		}
 } 
 else{
	 	$adddata  =  $app->addWithDupCheck($data_contact, 'Email');    // add contact by checking duplicate record
	 	//echo "sucessfully sent to infusionsoft";
		//echo "<pre>"; print_r($data_contact); echo "</pre>";
	 }
	
	//$adddata = $app->addCon($data_contact); // add record without duplicate check
	
	//$adddata = $app->updateCon('534',$data_contact);   //update a existing record
	
	if($adddata)
	{
	// API call to add tag to a contact
	$result1   = $app->grpAssign($adddata, $reading_tag);            
	$result2   = $app->grpAssign($adddata, $attention_tag);
	$result3   = $app->grpAssign($adddata, $workslow_tag);
	$result4   = $app->grpAssign($adddata, $math_tag);	
	$result5   = $app->grpAssign($adddata, $memory_tag);	
	$result6   = $app->grpAssign($adddata, $visualprcess_tag);
	$result7   = $app->grpAssign($adddata, $logicreason_tag);
	$result8   = $app->grpAssign($adddata, $autism_tag);	
	$result9   = $app->grpAssign($adddata, $homework_tag);
	$result10  = $app->grpAssign($adddata, $other_tag);

		$iddesss	=	array(3,22,24,26,32,34,36,38,40);

		if(in_array($sourceid,$iddesss))
		{
			$result11  = $app->grpAssign($adddata, 254);		
		}
	////// add contactnotes under contact us section ////
	
	/*
	$today = date('Ymj\TG:i:s');
	$addNote = array(
	'ContactId' => $adddata, 
	'CreationDate' => $today,
	'CompletionDate' => $today, 
	'ActionDate' => $today,
	'EndDate' => $today,
	'ActionType' => 'Other',
	'ActionDescription' => 'testing contacts',
	'CreationNotes' => $contact_notes
	);
	//$noteId = $app->dsAdd('ContactAction', $addNote);
	$noteId = $app->dsAdd('ContactNotes', $addNote);*/
	////////////////
	
	/// query to update record in the database
	$cont	   =	mysql_query("UPDATE imd_person_detail SET is_sent_to_infusoft=1 WHERE id_detail=".(int)$data['newLead']['LeadID']) or die(mysql_error());
	$controws  =    mysql_num_rows($cont);
	if(mysql_affected_rows($cont) != 1){
				//echo "<br /><br />Lead info could not sent to INFUSIONSOFT. IMD-INFUSIONSOFT: UPDATE failure code query unsuccessful. <br />";
				reportSystemError('IMD-INFUSIONSOFT: UPDATE failure code query unsuccessful', 'Following data was passed: '.var_export($data, true));
				}
	echo "Contact added sucessfully<br>";
	echo "New inserted id is".$adddata; 
	}
	else
	{
	 $qryfailed	 =	mysql_query("UPDATE imd_person_detail SET is_sent_to_infusoft=2 WHERE id_detail=".(int)$data['newLead']['LeadID']) or die(mysql_error());
	   $number		 =  mysql_num_rows($qryfailed);	
	   if((int)$number >= 1) {
	   reportSystemError('IMD-INFUSIONSOFT: Duplicate email sent to INFUSIONSOFT unsuccessful', 'Following data was passed: '.var_export($data, true));
	}
		
	
	}
				}
		else
		{
		reportSystemError('IMD-INFUSIONSOFT: Connection to INFUSIONSOFT unsuccessful', 'Following data was passed: '.var_export($data, true));
		}					
	}