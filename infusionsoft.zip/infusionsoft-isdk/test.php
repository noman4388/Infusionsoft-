<?php
   //Connects to the Infusionsoft API. This is a standard way to start any script that uses the Infusionsoft API. No tweaks necessary here!
   require("isdk.php");
   $app = new iSDK;
   $app->cfgCon('connectionName');
 
   //The variable (dateFieldName) stores the name of the custom Infusionsoft field where the date will be posted (NameOfYourDateField in this case).
   // Custom fields in Infusionsoft always have an underscore before their name when being referenced by a script.
   $dateFieldName = '_CenterCode';
 
   //Get post data for Contact ID.
   $contactId ='16';
 
   //Stores today's date in YearMonthDate format.
   $currentDate = date("YmdTH:i:s");
 
   //Grabs the data from Infusionsoft for your custom field.
   $returnFields = array($dateFieldName);
 
   //dsLoad is an Infusionsoft API method that grabs data from the specified field in Infusionsoft.
   $contacts = $app->dsLoad("Contact", $contactId, $returnFields);
 
   //If NameOfYourDateField is currently empty/unset, then set it to today's date. If it's already set, add one year to the date
   /*
   if (isset ($contacts['_NameOfYourDateField']) == FALSE) {
      $conDat = array($dateFieldName => $currentDate);
   } else {
      $classOf = strtotime($contacts['_NameOfYourDateField']);
      $yrPlusOne = date("YmdTH:i:s", strtotime('+1 year', $classOf));
      
   }
   */
    $yrPlusOne ='trx003';
    $conDat = array($dateFieldName => $yrPlusOne);
   //Another API method that updates a given contact with the data in the second variable passed.
   $conID = $app->updateCon($contactId, $conDat);
?>