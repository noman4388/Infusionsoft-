<?php
/*
$connInfo = array(
    "appname:appname:i:9ec0f20db7d49c9d8246dc1397c0ae45d8422fb80ea68c5ee18c7ab7b05da403:af249"
);*/

//$connInfo = array('af249:af249:i:9ec0f20db7d49c9d8246dc1397c0ae45d8422fb80ea68c5ee18c7ab7b05da403');

$connInfo =  array('connectionName:af249:i:9ec0f20db7d49c9d8246dc1397c0ae45d8422fb80ea68c5ee18c7ab7b05da403: You can place a note here');