<?php
	# name : imd_hub_cron.php 
	# desc : send leads from IMD to HUB via cron
	# version: 1.0
  	# changelog: 
	# 			2012/03/05 [Vikal]: start develop.

	//error_reporting(E_ALL);
	//ini_set("display_errors", 1);
	
	# Connect to DB
	require_once "\\\\webcontent01\\WebContent\\marketing\\__shared_library/db_imd_connect.php";	
	# Include libraries
	require_once "\\\\webcontent01\\WebContent\\marketing\\__shared_library/email_notification.php";
	
	# Initialize variables
	$info = array();
	$lsds_tables = array('imd_ppc_new_survey', 'imd_ppc_yahoo_survey', 'imd_ppc_msn_survey', 'imd_ppc_fb_survey', 'imd_wf_new_survey'); // LSDS tables
	$i = 0;
	
	# Fetch the leads which have not been sent to HUB, Flag - is_sent_to_hub = 0
	$qry = "	
		SELECT p.id_detail, p.id_addr, p.id_src, p.id_lead, p.id_center, p.first_name, p.last_name, CONCAT(p.area_code, '-', p.phone) AS phone, a.addr_street, a.addr_unit, a.city, a.state_code, a.zip_code, la.id_acc, la.email_addr, c.center_code,
			(SELECT ppc.id_ppc
				FROM 
					`imd_ppc` AS ppc,
					`imd_ppc_ans`AS ppc_ans
				WHERE 
					(ppc.id_ppc=ppc_ans.id_ppc) AND
					(ppc_ans.id_detail = p.id_detail)
				LIMIT 1
			UNION
			SELECT wf.id_wf
				FROM 
					`imd_wf` AS wf,
					`imd_wf_ans`AS wf_ans
				WHERE 
					(wf.id_wf=wf_ans.id_wf) AND
					(wf_ans.id_detail = p.id_detail)
				LIMIT 1) AS source,
			(SELECT ppc.table_name
				FROM 
					`imd_ppc` AS ppc,
					`imd_ppc_ans`AS ppc_ans
				WHERE 
					(ppc.id_ppc=ppc_ans.id_ppc) AND
					(ppc_ans.id_detail = p.id_detail)
				LIMIT 1
			UNION
			SELECT wf.table_name
				FROM 
					`imd_wf` AS wf,
					`imd_wf_ans`AS wf_ans
				WHERE 
					(wf.id_wf=wf_ans.id_wf) AND
					(wf_ans.id_detail = p.id_detail)
				LIMIT 1) AS table_name,
			(SELECT ppc_ans.id_ans
				FROM 
					`imd_ppc` AS ppc,
					`imd_ppc_ans`AS ppc_ans
				WHERE 
					(ppc.id_ppc=ppc_ans.id_ppc) AND
					(ppc_ans.id_detail = p.id_detail)
				LIMIT 1
			UNION
			SELECT wf_ans.id_ans
				FROM 
					`imd_wf` AS wf,
					`imd_wf_ans`AS wf_ans
				WHERE 
					(wf.id_wf=wf_ans.id_wf) AND
					(wf_ans.id_detail = p.id_detail)
				LIMIT 1) AS id_ans
		FROM 
			`imd_person_detail` AS p, 
			`lrx_address` AS a, 
			`imd_lead_account` AS la, 
			`imd_lead` AS l, 
			`lrx_center` AS c
		WHERE 
			(p.id_addr = a.id_addr) AND 
			(p.id_lead = l.id_lead) AND 
			(l.id_acc = la.id_acc) AND 
			(p.id_center = c.id_center) AND 
            (p.is_sent_to_infusoft = 2)
		";
	
	
	//(p.date_added >= DATE_SUB(NOW(), INTERVAL 1 DAY)) AND
	//echo $qry; exit;
	$sql = mysql_query($qry) or die('IMD-INFUSIONSOFT: SELECT query unsuccessful.');
	$num = mysql_num_rows($sql);
	//echo $qry;
	echo "Total number of leads found - ".(int)$num."<br/>";
	
	if((int)$num >= 1) {
		$emilto = "mah@evsoft.pk, glenn@learningrx.com, mark@learningrx.com, mumair@evsoft.pk";
		$headers = "From: Learningrx Alert <alert@learninrx.com>\n";
		$subject = "Leads Faild going to HUB";
		$message = "Hi,\n\n";
		$message .= (int)$num." Leads failed going to INFUSIONSOFT. Please check if imd_hub_cron cron Job is running!!!\n\n";
		$message .= "Thank you,\n\n";
		$message .= "LearningRx Team.\n\n";
		sendMail($emilto, $subject, $message, $headers, $type = "plain");
	}
	mysql_close($con);
	
	
?>
